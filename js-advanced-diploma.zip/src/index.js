import './css/style.css';
import './js/app';

// Точка входа webpack
// Не пишите код в данном файле
